package com.Fleming.sharemarket.common;

/**
 * Created by admin on 07-06-2017.
 */

public class AppUrl {
    public static String OPTION_CHAIN_URL = "http://www.google.com/finance/option_chain?q=";
    public static String SHARE_LIST = "http://www.google.com/finance/info?infotype=infoquoteall&q=NASDAQ:";
}
