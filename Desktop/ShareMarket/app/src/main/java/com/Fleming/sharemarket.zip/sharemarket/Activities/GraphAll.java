package com.Fleming.sharemarket.Activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.Fleming.sharemarket.common.ChainlistClass;
import com.Fleming.sharemarket.database.SQLiteHelper;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.toshiba.sharemarket.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.Fleming.sharemarket.Activities.GraphActivity.MY_COLORS;
import static com.Fleming.sharemarket.Activities.GraphActivity.listoperatorlist2;
import static com.Fleming.sharemarket.database.SQLiteHelper.KEY_ID;

public class GraphAll extends AppCompatActivity {
    String current_date, yester_date, then_yes_date;
    static SQLiteDatabase sqLiteDatabase;
    static SQLiteHelper sqLiteHelper;
    static BarChart barChart1;
    BarChart barChart2;
    BarChart barChart3;
    static ArrayList<ChainlistClass> listoperatorlist3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_all);

        sqLiteHelper = new SQLiteHelper(this);

//        Log.e("seema", "current_date" + GraphActivity.get_provider_data());


        current_date = getIntent().getStringExtra("date");
        Log.e("seema", "current_date" + current_date);
        barChart1 = (BarChart) findViewById(R.id.barchart);
        barChart2 = (BarChart) findViewById(R.id.barchart2);
        barChart2 = (BarChart) findViewById(R.id.barchart3);
//        getLocalSoloQuestions2(current_date);
        get_graph_values(current_date, barChart1);
//        Log.e("Name3333: ", "values",barChart1 + contacts);

        LinearLayout back = (LinearLayout) findViewById(R.id.back_menu_icn1);
        LinearLayout checklist = (LinearLayout) findViewById(R.id.checklist);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }


    public static void getLocalSoloQuestions2(String date_select) {

        String type_value_database;


        Log.e("see2", "share_type");

        listoperatorlist3 = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.query(sqLiteHelper.TABLE_NAME_CALLS, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {


            ChainlistClass get_provider_data = new ChainlistClass();
            get_provider_data.setId(cursor.getColumnIndex(KEY_ID));
            get_provider_data.setType(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_TYPE)));
            get_provider_data.setStrike_price(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_STRIKE_PRICE)));
            get_provider_data.setPrice_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_PRICE_VALUE)));
            get_provider_data.setChange_price_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_CHANGE_PRICE_VALUE)));
            get_provider_data.setBid_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_BIDVALUE)));
            get_provider_data.setAsk_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_ASK_VALUE)));
            get_provider_data.setVol_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_VOL_VALUE)));
            get_provider_data.setOp_int_value(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_OP_INT_VALUE)));
            get_provider_data.setTime(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_DATE_TIME)));
            if (date_select.equals(cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_DATE_TIME)))) {
//                listoperatorlist3.add(get_provider_data);
                listoperatorlist3.add(new ChainlistClass(get_provider_data.getOp_int_value(), get_provider_data.getStrike_price()));
                Log.e("Name3333: ", "" + get_provider_data.getOp_int_value());

            }


//
//            String date = "2017/07/20";
//
//
//            Log.e("seema", "snn" + cursor.getString(cursor.getColumnIndex(SQLiteHelper.KEY_DATE_TIME)));
//            if (date.equals(get_provider_data.getTime())) {
//                listoperatorlist2.add(get_provider_data);
//
//            }


            cursor.moveToNext();
            Log.e("Name5555: ", "" + get_provider_data.getOp_int_value());


            String log = " Type: " + get_provider_data.getType() + " ,Strike price : " + get_provider_data.getStrike_price() + " ,price: " + get_provider_data.getPrice_value() +
                    " ,change price value: " + get_provider_data.getChange_price_value() + " ,bid value: " + get_provider_data.getBid_value() + " ,ask value: " + get_provider_data.getAsk_value() +
                    " ,vol: " + get_provider_data.getAsk_value() + " ,op: " + get_provider_data.getOp_int_value() + " ,time: " + get_provider_data.getTime();
            // Writing Contacts to log
            Log.e("Name3333: ", "" + listoperatorlist3.size());


//                    username.setText(get_provider_data.getName());


        }
        cursor.close();
        //       sqLiteDatabase.delete(MySQLiteHelper.TABLE_COUPLES,null,null);

    }

    private static void get_graph_values(String current_date, BarChart barChart_main) {

        List<ChainlistClass> contacts = sqLiteHelper.getAllContacts(current_date);


        Log.e("reading", "reading" + contacts.size());

        ArrayList<BarEntry> entries = new ArrayList<>();

        for (int i=0;i<contacts.size();i++) {
            int amount_sum = Integer.parseInt(contacts.get(i).getOp_int_value());


            Log.e("share", "amount_sums" + amount_sum);
            if (amount_sum != 0) {
                entries.add(new BarEntry(amount_sum, i));

            }
        }


//        for (int i = 0; i < listoperatorlist3.size(); i++) {
//
//
//        }
        BarDataSet bardataset = new BarDataSet(entries, "");

        ArrayList<String> labels = new ArrayList<String>();

        for (int i=0;i<contacts.size();i++) {
            String amount_sum1 = contacts.get(i).getStrike_price();
            Log.e("share", "amount_sum1" + amount_sum1);

            if (!contacts.get(i).getStrike_price().equals("0")) {
                labels.add(amount_sum1);


            }
        }

        // adding colors
        ArrayList<Integer> colors = new ArrayList<Integer>();

        // Added My Own colors
        for (int c : MY_COLORS)
            colors.add(c);


        bardataset.setColors(colors);

        //  create pie data object and set xValues and yValues and set it to the pieChart
        BarData data = new BarData(labels, bardataset);

//        data.setValueTextSize(11f);
        bardataset.setColors(MY_COLORS);


//        data.setValueTextSize(11f);
        data.setValueTextColor(Color.WHITE);


        barChart_main.setData(data); // set the data and list of lables into chart

        // undo all highlights
        barChart_main.highlightValues(null);
        barChart_main.setNoDataText("loading");
        barChart_main.setNoDataTextDescription("");

        // refresh/update pie chart
        barChart_main.invalidate();


        barChart_main.setDrawGridBackground(false);
        barChart_main.getXAxis().setTextColor(Color.WHITE);
        barChart_main.getAxisLeft().setTextColor(Color.TRANSPARENT);
        barChart_main.getAxisRight().setTextColor(Color.WHITE);

        barChart_main.getXAxis().setDrawGridLines(false);
        barChart_main.getXAxis().setDrawAxisLine(true);
        barChart_main.getAxisLeft().setDrawGridLines(false);
        barChart_main.getAxisLeft().setDrawAxisLine(false);
        barChart_main.getAxisRight().setDrawGridLines(false);
        barChart_main.getAxisRight().setDrawAxisLine(true);
        barChart_main.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        barChart_main.animateXY(1400, 5000);


        // Legends to show on bottom of the graph
        Legend l = barChart_main.getLegend();
        l.setPosition(Legend.LegendPosition.BELOW_CHART_RIGHT);
        l.setXEntrySpace(20);
        l.setYEntrySpace(10);


    }


}
