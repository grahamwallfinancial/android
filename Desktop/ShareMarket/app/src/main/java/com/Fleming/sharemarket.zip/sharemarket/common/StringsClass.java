package com.Fleming.sharemarket.common;

/**
 * Created by arjun on 19/01/2017.
 */

public class StringsClass {

    public  static  String loading="Loading";
    public  static  String plswait="Please wait while we are progressing";

}
